package com.smart.entities;

import lombok.*;

import javax.persistence.*;

/**
 *This is instructor class
 * used for records of instructor
 */
@Entity
@Table(name="instructor")
@ToString
public class Instructor {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int insId;
    private String name;
    private String secondName;
    private String work;
    private String course;
    private String courseId;
    private String email;
    private String phone;
    @Column(length = 500)
    private String about;
	public int getInsId() {
		return insId;
	}
	public void setInsId(int insId) {
		this.insId = insId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSecondName() {
		return secondName;
	}
	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}
	public String getWork() {
		return work;
	}
	public void setWork(String work) {
		this.work = work;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getCourseId() {
		return courseId;
	}
	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAbout() {
		return about;
	}
	public void setAbout(String about) {
		this.about = about;
	}

}
