package com.smart.controller;

import java.security.Principal;

import com.smart.dao.CourseRepository;
import com.smart.dao.InstructorRepository;
import com.smart.dao.StudentRepository;
import com.smart.entities.Course;
import com.smart.entities.Instructor;
import com.smart.entities.Student;
import com.smart.helper.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.smart.dao.UserRepository;
import com.smart.entities.User;

import javax.servlet.http.HttpSession;

/**
 * User Controller controls all urls after logging in
 */
@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private InstructorRepository instructorRepository;
	@Autowired
	private CourseRepository courseRepository;
	@Autowired
	private StudentRepository studentRepository;
	// method for adding common data to response

	/**
	 * To add the common data means sending user that is currently logged in
	 * @param model
	 * @param principal
	 */
	@ModelAttribute
	public void addCommonData(Model model, Principal principal) {
		String userName = principal.getName();
		System.out.println("USERNAME " + userName);

		// get the user using usernamne(Email)

		User user = userRepository.getUserByUserName(userName);
		System.out.println("USER " + user);
		model.addAttribute("user", user);

	}

	/**
	 * used for viewing profile
	 * @param model
	 * @return
	 */
	@GetMapping("/profile")
	public String yourProfile(Model model) {
		model.addAttribute("title", "Profile Page");
		return "normal/profile";
	}

	/**
	 * directs to index page
	 * @param model
	 * dashboard home
	 * @param principal
	 * @return
	 */
	@RequestMapping("/index")
	public String dashboard(Model model, Principal principal) {
		model.addAttribute("title", "User Dashboard");
		return "normal/user_dashboard";
	}

	/**
	 * open add instructor form handler
	 * used for adding instructor
	 * @param model
	 * @return
	 */
	@GetMapping("/add-instructor")
	public String openAddContactForm(Model model) {
		model.addAttribute("title", "Add Instructor");
		model.addAttribute("contact", new Instructor());

		return "normal/add_instructor_form";
	}

	/**
	 * this url processes the data from instructor page and verifies and then saves to db
	 * rocessing add contact form
	 * @param instructor
	 * @param session
	 * @return
	 */
	@PostMapping("/process-instructor")
	public String processContact(@ModelAttribute("instructor") Instructor instructor, HttpSession session) {
		try {
			Course course= courseRepository.findByCourseId(instructor.getCourseId());
			instructor.setCourse(course.getName());
			Instructor instructor1= instructorRepository.save(instructor);
			System.out.println("DATA " + instructor1);
			System.out.println("Added to data base");
			// message success.......
			session.setAttribute("message", new Message("Your instructor is added !! Add more..", "success"));
		} catch (Exception e) {
			System.out.println("ERROR " + e.getMessage());
			e.printStackTrace();
			// message error
			session.setAttribute("message", new Message("Some went wrong !! Try again..", "danger"));

		}

		return "normal/add_instructor_form";
	}

	/**
	 * this page is for adding course details
	 * @param model
	 * @return
	 */
	//	 open add form handler
	@GetMapping("/add-course")
	public String openAddCoursetForm(Model model) {
		model.addAttribute("title", "Add Course");
		model.addAttribute("contact", new Course());

		return "normal/add_course_form";
	}

	/**
	 * this method process course details, verifies and then saves to db
	 * processing add contact form
	 * @param course
	 * @param session
	 * @return
	 */
	@PostMapping("/process-course")
	public String processCourse(@ModelAttribute("course") Course course, HttpSession session) {

		try {
			// processing and uploading file..
			Course course1= courseRepository.save(course);

			System.out.println("DATA " + course1);

			System.out.println("Added to data base");

			// message success.......
			session.setAttribute("message", new Message("Your course is added !! Add more..", "success"));

		} catch (Exception e) {
			System.out.println("ERROR " + e.getMessage());
			e.printStackTrace();
			// message error
			session.setAttribute("message", new Message("Some went wrong !! Try again..", "danger"));

		}

		return "normal/add_course_form";
	}

	/**
	 * this page is for adding student
	 * @param model
	 * @return
	 */
	@GetMapping("/add-student")
	public String openAddStudentForm(Model model) {
		model.addAttribute("title", "Add Student");
		model.addAttribute("contact", new Student());

		return "normal/add_student_form";
	}

	/**
	 * this method process students details, verifies and then saves to db
	 * processing add contact form
	 * @param student
	 * @param session
	 * @return
	 */
	@PostMapping("/process-student")
	public String processStudent(@ModelAttribute("student") Student student
			, HttpSession session) {

		try {


			// processing and uploading file..
			Course course= courseRepository.findByCourseId(student.getCourseId());
			student.setCourse(course.getName());
			Student student1= studentRepository.save(student);

			System.out.println("DATA " + student1);

			System.out.println("Added to data base");

			// message success.......
			session.setAttribute("message", new Message("Your student is added !! Add more..", "success"));

		} catch (Exception e) {
			System.out.println("ERROR " + e.getMessage());
			e.printStackTrace();
			// message error
			session.setAttribute("message", new Message("Some went wrong !! Try again..", "danger"));

		}

		return "normal/add_student_form";
	}

	/**
	 * shows the course list
	 * show courses
	 * @param page
	 * @param m
	 * @return
	 */
	@GetMapping("/show-c/{page}")
	public String showContacts(@PathVariable("page") Integer page, Model m) {
		m.addAttribute("title", "Show User Courses");
		// currentPage-page
		// Contact Per page - 5
		Pageable pageable = PageRequest.of(page, 8);
		Page<Course> contacts = courseRepository.findContactsByUser(pageable);
		m.addAttribute("contacts", contacts);
		m.addAttribute("currentPage", page);
		m.addAttribute("totalPages", contacts.getTotalPages());
		return "normal/show_c";
	}

	/**
	 * deletes the course by id
	 * delete courses
	 * @param cId
	 * @param model
	 * @param session
	 * @return
	 */
	@GetMapping("/delete/{cid}")
	@Transactional
	public String deleteContact(@PathVariable("cid") Integer cId, Model model, HttpSession session) {
		System.out.println("CID " + cId);
		courseRepository.deleteById(cId);
		System.out.println("DELETED");
		session.setAttribute("message", new Message("Contact deleted succesfully...", "success"));
		return "redirect:/user/show-c/0";
	}

	/**
	 * shows the students list
	 * show students
	 * @param page
	 * @param m
	 * @return
	 */
	@GetMapping("/show-students/{page}")
	public String showStudents(@PathVariable("page") Integer page, Model m) {
		m.addAttribute("title", "Show User Contacts");
		// currentPage-page
		// Contact Per page - 5
		Pageable pageable = PageRequest.of(page, 8);
		Page<Student> contacts = studentRepository.findContactsByUser(pageable);
		m.addAttribute("contacts", contacts);
		m.addAttribute("currentPage", page);
		m.addAttribute("totalPages", contacts.getTotalPages());
		return "normal/show_students";
	}

	/**
	 * deletes the student with id
	 * delete student
	 * @param cId
	 * @param model
	 * @param session
	 * @return
	 */
	@GetMapping("/student/delete/{cid}")
	@Transactional
	public String deleteStudent(@PathVariable("cid") Integer cId, Model model, HttpSession session) {
		System.out.println("CID " + cId);
		studentRepository.deleteById(cId);
		System.out.println("DELETED");
		session.setAttribute("message", new Message("Contact deleted succesfully...", "success"));
		return "redirect:/user/show-students/0";
	}

	/**
	 * shows the instructor list
	 * @param page
	 * @param m
	 * @return
	 */
	@GetMapping("/show-instructors/{page}")
	public String showInstructors(@PathVariable("page") Integer page, Model m) {
		m.addAttribute("title", "Show User Contacts");
		// currentPage-page
		// Contact Per page - 5
		Pageable pageable = PageRequest.of(page, 8);
		Page<Instructor> contacts = instructorRepository.findContactsByUser(pageable);
		m.addAttribute("contacts", contacts);
		m.addAttribute("currentPage", page);
		m.addAttribute("totalPages", contacts.getTotalPages());
		return "normal/show_instructors";
	}

	/**
	 * deletes instructors by id
	 * delete courses
	 * @param cId
	 * @param model
	 * @param session
	 * @return
	 */
	@GetMapping("/instructor/delete/{cid}")
	@Transactional
	public String deleteInstructor(@PathVariable("cid") Integer cId, Model model, HttpSession session) {
		System.out.println("CID " + cId);
		instructorRepository.deleteById(cId);
		System.out.println("DELETED");
		session.setAttribute("message", new Message("Contact deleted succesfully...", "success"));
		return "redirect:/user/show-instructors/0";
	}



}
