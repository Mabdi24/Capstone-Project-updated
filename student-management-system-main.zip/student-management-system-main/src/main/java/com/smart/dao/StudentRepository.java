package com.smart.dao;

import com.smart.entities.Course;
import com.smart.entities.Student;
import com.smart.entities.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
/**
 * this is student repository, in this we write the server queries to obtain data from server
 */
public interface StudentRepository extends JpaRepository<Student, Integer> {
	/**
	 * find student with email and return
	 * @param email
	 * @return
	 */
	@Query("select u from User u where u.email = :email")
	public User getUserByUserName(@Param("email") String email);

	/**
	 * Contact Per page - 5
	 * currentPage-page
	 * return student list
	 * @param pePageable
	 * @return
	 */
	@Query("select student from Student student ")
	public Page<Student> findContactsByUser(Pageable pePageable);
}
