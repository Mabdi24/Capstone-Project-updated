package com.smart.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.smart.entities.User;

/**
 * this is user repository, in this we write the server queries to obtain data from server
 */
public interface UserRepository extends JpaRepository<User, Integer> {
	/**
	 * find user with email and return
	 * @param email
	 * @return
	 */
	@Query("select u from User u where u.email = :email")
	public User getUserByUserName(@Param("email") String email);
}
