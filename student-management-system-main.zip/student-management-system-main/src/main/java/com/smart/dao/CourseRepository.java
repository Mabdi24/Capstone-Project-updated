package com.smart.dao;

import com.smart.entities.Course;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 * this is course repository, in this we write the server queries to obtain data from server
 */
public interface CourseRepository extends JpaRepository<Course, Integer> {
    /**
     * find course with id and return it
     * @param courseId
     * @return
     */
	@Query("select c from Course c where c.courseId =?1")
	public Course findByCourseId(String courseId);

    /**
     * return all courses list
     * @param pePageable
     * currentPage-page
     * Contact Per page - 5
     * @return
     */
    @Query("select course from Course course ")
    public Page<Course> findContactsByUser( Pageable pePageable);
}
