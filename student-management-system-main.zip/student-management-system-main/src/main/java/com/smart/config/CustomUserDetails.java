package com.smart.config;

import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.smart.entities.User;

/**
 * In this class, user details are implemented by security method called UserDetails
 * Doing this for athentication of user
 */
public class CustomUserDetails implements UserDetails {

	private User user;

	/**
	 * To setup custom user details
	 * @param user
	 */
	public CustomUserDetails(User user) {
		super();
		this.user = user;
	}

	/**
	 * to set up granted authority
	 * @return
	 */
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {

		SimpleGrantedAuthority simpleGrantedAuthority = new SimpleGrantedAuthority(user.getRole());
		return List.of(simpleGrantedAuthority);
	}

	/**
	 * To get the password
	 * @return
	 */
	@Override
	public String getPassword() {
		return user.getPassword();
	}

	/**
	 * To get the username
	 * @return
	 */
	@Override
	public String getUsername() {

		return user.getEmail();
	}

	/**
	 * to check if account is expired or not
	 * @return
	 */
	@Override
	public boolean isAccountNonExpired() {

		return true;
	}

	/**
	 * to check if account is locked or not
	 * @return
	 */
	@Override
	public boolean isAccountNonLocked() {

		return true;
	}

	/**
	 * to check for credentials
	 * @return
	 */
	@Override
	public boolean isCredentialsNonExpired() {

		return true;
	}

	/**
	 * to check if account is enabled or not?
	 * @return
	 */
	@Override
	public boolean isEnabled() {

		return true;
	}

}
