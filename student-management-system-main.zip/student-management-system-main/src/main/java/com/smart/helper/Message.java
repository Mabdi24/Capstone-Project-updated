package com.smart.helper;

/**
 *this class is responsible for generating proper messages for exception handling
 */
public class Message {

	private String content;
	private String type;

	/**
	 * gets content and type and returns proper message
	 * @param content
	 * @param type
	 */
	public Message(String content, String type) {
		super();
		this.content = content;
		this.type = type;
	}

	/**
	 * function to return the content of the error
	 * @return
	 */
	public String getContent() {
		return content;
	}

	/**
	 * function to set the content of the error
	 * @param content
	 */
	public void setContent(String content) {
		this.content = content;
	}

	/**
	 * function to get the type of the error
	 * @return
	 */
	public String getType() {
		return type;
	}

	/**
	 * Function to set the type of the error
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	
	
}
